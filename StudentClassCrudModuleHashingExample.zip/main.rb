require_relative 'crud'
 
users = [
          { username: "tom", password: "password1" },
          { username: "stu", password: "password2" },
          { username: "prk", password: "password3" },
          { username: "jim", password: "password4" },
          { username: "kip", password: "password5" }
        ]
 
hashed_users = Crud.create_secure_users(users)
puts hashed_users